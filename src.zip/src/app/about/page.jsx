export default function About() {
    return (
        <>
            <h1 className="text-xl">About</h1>
        </>
    )
}