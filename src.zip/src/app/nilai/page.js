export default function Nilai() {
    return (
        <>
            <h1 className="text-xl font-semibold">
                Halaman Nilai
            </h1>
        </>
    )
}