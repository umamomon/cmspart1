export default function Admin() {
    return (
        <>
            <h1 className="text-xl">Ini Halaman Admin</h1>
        </>
    )
}